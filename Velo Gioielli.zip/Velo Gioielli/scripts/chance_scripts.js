$(document).ready(function() {
		// jQuery code goes here
		
/*		
/////////////////////////////////////START STICKY AV/////////////////////////////////////////////////

		//Calculate the height of <header>
	//Use outerHeight() instead of height() if have padding
    var aboveHeight = $('header').outerHeight();
    

	// when scroll
    $(window).scroll(function(){
		
		//if scrolled down more than the header's height
        if ($(window).scrollTop() > aboveHeight){
			
			// if yes, add "fixed" class to the <nav>
			// add padding top to the #content (value is same as the height of the nav)
            $('.navBar').addClass('fixed').css('top','0');
            $('#content').css('padding-top','7.5em');
        } else {
			
			// when scroll up or less than aboveHeight, remove the "fixed" class, and the padding-top
            $('.navBar').removeClass('fixed');
            $('#content').css('padding-top','0');

        }
    });
	
/////////////////////////////////////START SLIDESHOW/////////////////////////////////////////////////

		$(function() {
			$(".rslides").responsiveSlides();
    	});

/////////////////////////////////////START STELLAR/////////////////////////////////////////////////
		//$('#content').hide();
		
		$(window).stellar();

  // LINK TO SECTION OF PAGE
    $('.pattern').click(function() {

        //alert('js working'); 
        // TARGET --> SPEED
		$('#content').show();
        
        $(window).scrollTo(".navWrapper", 800);
    });
    
    // LINK TO SECTION OF PAGE






*/

});  
